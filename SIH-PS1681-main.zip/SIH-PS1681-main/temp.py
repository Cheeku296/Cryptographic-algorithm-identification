mybytes = b"Hello World!"
print(f"{mybytes} are nice".encode())

list = [183, 1, 160, 172]
bytestemp = bytes(list)
print(bytestemp)
print(bytestemp.hex())

# \xb7\x01\xa0\xac

print(len(bytestemp))

#LEFT
'''
JH

RSA
'''